<?php 
session_start();
session_destroy();
?>

<script>
    document.location.href = '../index.php';
</script>