<?php
$konek = new mysqli("localhost", "root", "", "labuanbajo");
?>